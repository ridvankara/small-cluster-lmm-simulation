###############################################################################
# FAZ 2 — Kapsam Genisletme: Coklu Kovaryat + Eksik Veri
# Ridvan Kara — Communications in Statistics - Simulation and Computation
#
# R1 madde 9 + R2-a cevabi. Sadece FREKENTIST (KR / Satterthwaite / REML) —
# asil soru df-duzeltmelerinin bu stresler altinda gecerliligi; hizli.
#
# Modul A (kovaryat): Y ~ X1 + X2 + X3 + (1|cluster), X1 test edilir (beta1),
#                     X2/X3 nuisance (beta2=0.5, beta3=0.3). Daha cok parametre
#                     -> daha az kalan sd -> kucuk-orneklem duzeltmeleri daha kritik.
# Modul B (eksik):    Y ~ X + (1|cluster), Y'ye %20 eksiklik. MCAR + MAR.
#                     MAR: eksiklik gozlenen X'e bagli (ignorable, modelde X var).
#
# Grid: J=(3,5,10,15) x n=(20,50) x ICC=(0.05,0.30) x beta1=(0,0.3,0.5), dengeli.
#   Modul A: 48 kosul | Modul B: 48 x 2 mekanizma = 96 | toplam 144.
# Uretilebilir: her kosul seed=2025+condition_id.
###############################################################################

.libPaths(c("C:/R_Cloud_Fix", "C:/Program Files/R/R-4.5.2/library"))
cat("\n>>> FAZ 2 PIPELINE | kovaryat(3) + eksik(%20, MCAR/MAR) | frekentist <<<\n\n")

## ======================================================= AYARLAR
DIR      <- "C:/simulation_lmm"
SEED     <- 2025
WORKERS  <- 3          # frekentist hafif; 8GB'da 3 rahat
N_REP    <- 1000       # replikasyon / kosul (MCSE ~0.007)

RUN_P2   <- TRUE
RUN_AGG  <- TRUE

# Modul parametreleri
P2_J     <- c(3, 5, 10, 15)
P2_N     <- c(20, 50)
P2_ICC   <- c(0.05, 0.30)
P2_BETA  <- c(0, 0.3, 0.5)
BETA2    <- 0.5        # nuisance kovaryat X2 etkisi
BETA3    <- 0.3        # nuisance kovaryat X3 etkisi
MISS_RATE<- 0.20       # eksiklik orani (Y uzerinde)

dir.create(DIR, showWarnings = FALSE, recursive = TRUE)

## ======================================================= PAKET KONTROLU
.need <- c("lme4","lmerTest","pbkrtest","furrr","future","dplyr")
.miss <- .need[!vapply(.need, requireNamespace, logical(1), quietly=TRUE)]
if (length(.miss)) stop("Eksik paket(ler): ", paste(.miss, collapse=", "))

## ======================================================= DGP FONKSIYONLARI
# Modul A: 3 kovaryatli (dengeli)
make_data_mv <- function(J, n_target, icc, beta1) {
  sigma2_u <- icc; sigma2_e <- 1 - icc
  nj  <- rep(as.integer(n_target), J)
  N   <- sum(nj); cid <- rep(seq_len(J), times = nj)
  uj  <- rnorm(J, 0, sqrt(sigma2_u)); e <- rnorm(N) * sqrt(sigma2_e)
  X1 <- rnorm(N); X2 <- rnorm(N); X3 <- rnorm(N)
  Y  <- beta1*X1 + BETA2*X2 + BETA3*X3 + uj[cid] + e
  data.frame(Y=Y, X1=X1, X2=X2, X3=X3, cluster=factor(cid))
}

# Modul B: tek yordayici + eksiklik (dengeli)
make_data_miss <- function(J, n_target, icc, beta1, mechanism, rate) {
  sigma2_u <- icc; sigma2_e <- 1 - icc
  nj  <- rep(as.integer(n_target), J)
  N   <- sum(nj); cid <- rep(seq_len(J), times = nj)
  uj  <- rnorm(J, 0, sqrt(sigma2_u)); e <- rnorm(N) * sqrt(sigma2_e)
  X   <- rnorm(N)
  Y   <- beta1*X + uj[cid] + e
  if (identical(mechanism, "MCAR")) {
    miss <- runif(N) < rate
  } else {  # MAR: eksiklik gozlenen X'e bagli, ~rate'e kalibre
    miss <- runif(N) < plogis(qlogis(rate) + 1.0 * X)
  }
  Y[miss] <- NA
  data.frame(Y=Y, X=X, cluster=factor(cid))
}

# Ortak cikarim: tek fit -> REML(z) / Satterthwaite / KR, hedef terim icin
infer3 <- function(dat, form, target, truth, alpha=0.05) {
  fit <- tryCatch(lmerTest::lmer(form, data=dat, REML=TRUE), error=function(e) NULL)
  if (is.null(fit)) return(NULL)
  conv <- tryCatch(as.integer(is.null(fit@optinfo$conv$lme4$messages)),
                   error=function(e) NA_integer_)
  b      <- tryCatch(unname(lme4::fixef(fit)[target]), error=function(e) NA_real_)
  se_raw <- tryCatch(sqrt(vcov(fit)[target,target]),   error=function(e) NA_real_)
  if (is.na(b) || is.na(se_raw)) return(NULL)
  rows <- list()

  # REML (duzeltilmemis; asimptotik z)
  z <- b/se_raw; pv <- 2*pnorm(abs(z), lower.tail=FALSE)
  ci <- b + c(-1,1)*qnorm(1-alpha/2)*se_raw
  rows$reml <- data.frame(method="REML", estimate=b, se=se_raw, df=NA_real_,
    pval=pv, ci_lo=ci[1], ci_hi=ci[2], rejected=as.integer(pv<alpha),
    covered=as.integer(ci[1]<=truth & truth<=ci[2]), converged=conv)

  # Satterthwaite
  cs <- tryCatch(summary(fit, ddf="Satterthwaite")$coefficients, error=function(e) NULL)
  if (!is.null(cs) && target %in% rownames(cs)) {
    se<-cs[target,"Std. Error"]; df<-cs[target,"df"]; p<-cs[target,"Pr(>|t|)"]
    ci<-b+c(-1,1)*qt(1-alpha/2,df)*se
    rows$satt <- data.frame(method="Satterthwaite", estimate=b, se=se, df=df,
      pval=p, ci_lo=ci[1], ci_hi=ci[2], rejected=as.integer(p<alpha),
      covered=as.integer(ci[1]<=truth & truth<=ci[2]), converged=conv)
  }

  # Kenward-Roger
  ck <- tryCatch(summary(fit, ddf="Kenward-Roger")$coefficients, error=function(e) NULL)
  if (!is.null(ck) && target %in% rownames(ck)) {
    se<-ck[target,"Std. Error"]; df<-ck[target,"df"]; p<-ck[target,"Pr(>|t|)"]
    ci<-b+c(-1,1)*qt(1-alpha/2,df)*se
    rows$kr <- data.frame(method="KR", estimate=b, se=se, df=df,
      pval=p, ci_lo=ci[1], ci_hi=ci[2], rejected=as.integer(p<alpha),
      covered=as.integer(ci[1]<=truth & truth<=ci[2]), converged=conv)
  }
  do.call(rbind, rows)
}

## ======================================================= PART D: FAZ 2 SIMULASYON
if (RUN_P2) {
  library(furrr); library(future); library(dplyr)
  plan(multisession, workers = WORKERS)

  CKPT <- file.path(DIR, "sim_phase2_checkpoint.rds")
  OUT  <- file.path(DIR, "sim_phase2_results.rds")

  gA <- expand.grid(J=P2_J, n=P2_N, icc=P2_ICC, beta1=P2_BETA,
                    stringsAsFactors=FALSE)
  gA$module <- "covariates"; gA$mechanism <- NA_character_
  gB <- expand.grid(J=P2_J, n=P2_N, icc=P2_ICC, beta1=P2_BETA,
                    mechanism=c("MCAR","MAR"), stringsAsFactors=FALSE)
  gB$module <- "missing"
  grid <- bind_rows(gA, gB)
  grid$condition_id <- seq_len(nrow(grid))

  done <- if (file.exists(CKPT)) unique(readRDS(CKPT)$condition_id) else integer(0)
  todo <- grid[!grid$condition_id %in% done, ]
  cat(sprintf("\n[P2] toplam %d | tamamlanan %d | kalan %d\n",
              nrow(grid), length(done), nrow(todo)))

  if (nrow(todo) > 0) {
    batches <- split(seq_len(nrow(todo)), ceiling(seq_len(nrow(todo))/WORKERS))
    t0 <- proc.time()

    for (b in seq_along(batches)) {
      bg <- todo[batches[[b]], , drop=FALSE]
      cat(sprintf("[%s] P2 batch %d/%d — kosul %d:%d\n",
          format(Sys.time(),"%H:%M"), b, length(batches),
          bg$condition_id[1], bg$condition_id[nrow(bg)]))

      res <- future_map_dfr(seq_len(nrow(bg)), function(i) {
        .libPaths(c("C:/R_Cloud_Fix","C:/Program Files/R/R-4.5.2/library"))
        library(lme4); library(lmerTest); library(pbkrtest)
        cond <- bg[i, ]
        set.seed(SEED + cond$condition_id)
        out <- vector("list", N_REP)

        for (r in seq_len(N_REP)) {
          if (cond$module == "covariates") {
            dat <- make_data_mv(cond$J, cond$n, cond$icc, cond$beta1)
            rr  <- infer3(dat, Y ~ X1 + X2 + X3 + (1|cluster), "X1", cond$beta1)
          } else {
            dat <- make_data_miss(cond$J, cond$n, cond$icc, cond$beta1,
                                  cond$mechanism, MISS_RATE)
            rr  <- infer3(dat, Y ~ X + (1|cluster), "X", cond$beta1)
          }
          if (!is.null(rr)) {
            rr$rep_id<-r; rr$condition_id<-cond$condition_id
            rr$J<-cond$J; rr$n_target<-cond$n; rr$icc<-cond$icc
            rr$beta1<-cond$beta1; rr$module<-cond$module; rr$mechanism<-cond$mechanism
          }
          out[[r]] <- rr
        }
        do.call(rbind, Filter(Negate(is.null), out))
      }, .options = furrr_options(seed = TRUE))

      prev <- if (file.exists(CKPT)) readRDS(CKPT) else NULL
      saveRDS(rbind(prev, res), CKPT); rm(res, prev); gc()
      el <- round((proc.time()-t0)["elapsed"]/60,1)
      cat(sprintf("  bitti — gecen %.1f dk | tahmini kalan %.1f dk\n",
                  el, round(el/b*(length(batches)-b),1)))
    }
  }
  saveRDS(readRDS(CKPT), OUT)
  cat(sprintf("[P2] TAMAM — satir: %d\n", nrow(readRDS(OUT))))
}

## ======================================================= PART E: OZET
if (RUN_AGG) {
  library(dplyr)
  d <- readRDS(file.path(DIR,"sim_phase2_results.rds"))
  d$grp <- ifelse(is.na(d$mechanism), d$module, paste0(d$module,"-",d$mechanism))

  cell <- d %>%
    group_by(grp, method, J, n_target, icc, beta1) %>%
    summarise(R=dplyr::n(),
              reject=mean(rejected,na.rm=TRUE),
              reject_mcse=sqrt(reject*(1-reject)/R),
              coverage=mean(covered,na.rm=TRUE),
              conv_rate=mean(converged,na.rm=TRUE),
              .groups="drop")

  saveRDS(cell, file.path(DIR,"summary_phase2.rds"))

  cat("\n=============== FAZ 2 OZET ===============\n")

  cat("\n--- TIP I HATA (grup x yontem, beta1=0) ---\n")
  print(as.data.frame(cell %>% filter(beta1==0) %>% group_by(grp,method) %>%
    summarise(mean_typeI=round(mean(reject),4),
              max_typeI=round(max(reject),4),
              bradley_ok=round(mean(reject>=0.025 & reject<=0.075),3),
              .groups="drop")))

  cat("\n--- GUC (grup x yontem, beta1=0.3) ---\n")
  print(as.data.frame(cell %>% filter(beta1==0.3) %>% group_by(grp,method) %>%
    summarise(mean_power=round(mean(reject),3), .groups="drop")))

  cat("\n--- KAPSAMA (grup x yontem, beta1=0) ---\n")
  print(as.data.frame(cell %>% filter(beta1==0) %>% group_by(grp,method) %>%
    summarise(mean_cov=round(mean(coverage),4), .groups="drop")))

  cat("\n--- YAKINSAMA ORANI (grup x J) ---\n")
  print(as.data.frame(cell %>% group_by(grp,J) %>%
    summarise(conv_rate=round(mean(conv_rate),4), .groups="drop")))

  cat("\n[P2-AGG] Kaydedildi: summary_phase2.rds\n")
}
