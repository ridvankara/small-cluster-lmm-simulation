###############################################################################
# KOVA C — Yakinsama / Singular-fit / Boundary + Sensitivity alt-calismasi
# Ridvan Kara — Communications in Statistics (revizyon, hakem 1.7 / 4.2 / 12)
#
# Amac: J=3,5 rejiminde her replikasyon icin yakinsama durumunu kaydet;
#   (a) yakinsama / singular-fit / boundary oranlari yonteme ve J'ye gore,
#   (b) SENSITIVITY: yakinsamayanlar DAHIL vs HARIC Tip I hata ve guc.
# Boylece ana sonuclarin "basarili-fit kosullu" olup olmadigi gosterilir.
#
# Not: ana frekentist simulasyon lmer'in dondurdugu her fit'i (uyari olsa da)
#   tutuyordu; bu alt-calisma o durumu dogrular ve dislama etkisini olcer.
###############################################################################

.libPaths(c("C:/R_Cloud_Fix", "C:/Program Files/R/R-4.5.2/library"))
cat("\n>>> KOVA C — yakinsama/sensitivity alt-calismasi <<<\n\n")

DIR     <- "C:/simulation_lmm"
SEED    <- 2025
WORKERS <- 3
N_REP   <- 1000

# Odakli grid: yakinsamanin kritik oldugu kucuk-J rejimi
CJ    <- c(3, 5)
CN    <- c(20, 50)
CICC  <- c(0.05, 0.30)
CBAL  <- c("balanced", "unbalanced")
CBETA <- c(0, 0.3)     # 0 = Tip I ; 0.3 = guc

dir.create(DIR, showWarnings = FALSE, recursive = TRUE)
.need <- c("lme4","lmerTest","furrr","future","dplyr")
.miss <- .need[!vapply(.need, requireNamespace, logical(1), quietly=TRUE)]
if (length(.miss)) stop("Eksik paket: ", paste(.miss, collapse=", "))

## DGP (ana pipeline ile AYNI: dengesiz = Uniform[0.5n,1.5n]) ------------------
make_data <- function(J, n_target, icc, beta1, balance) {
  s2u <- icc; s2e <- 1 - icc
  if (identical(balance,"unbalanced")) nj <- pmax(5L, as.integer(round(runif(J, 0.5*n_target, 1.5*n_target))))
  else nj <- rep(as.integer(n_target), J)
  N <- sum(nj); cid <- rep(seq_len(J), times=nj)
  uj <- rnorm(J,0,sqrt(s2u)); e <- rnorm(N)*sqrt(s2e); X <- rnorm(N)
  data.frame(Y=beta1*X + uj[cid] + e, X=X, cluster=factor(cid))
}

if (TRUE) {
  library(furrr); library(future); library(dplyr)
  plan(multisession, workers = WORKERS)
  CKPT <- file.path(DIR,"sim_conv_checkpoint.rds")
  OUT  <- file.path(DIR,"sim_conv_results.rds")

  grid <- expand.grid(J=CJ, n=CN, icc=CICC, balance=CBAL, beta1=CBETA,
                      stringsAsFactors=FALSE)
  grid$condition_id <- seq_len(nrow(grid))
  done <- if (file.exists(CKPT)) unique(readRDS(CKPT)$condition_id) else integer(0)
  todo <- grid[!grid$condition_id %in% done, ]
  cat(sprintf("[CONV] toplam %d | tamamlanan %d | kalan %d\n", nrow(grid), length(done), nrow(todo)))

  if (nrow(todo) > 0) {
    batches <- split(seq_len(nrow(todo)), ceiling(seq_len(nrow(todo))/WORKERS))
    t0 <- proc.time()
    for (b in seq_along(batches)) {
      bg <- todo[batches[[b]], , drop=FALSE]
      cat(sprintf("[%s] CONV batch %d/%d\n", format(Sys.time(),"%H:%M"), b, length(batches)))
      res <- future_map_dfr(seq_len(nrow(bg)), function(i){
        .libPaths(c("C:/R_Cloud_Fix","C:/Program Files/R/R-4.5.2/library"))
        library(lme4); library(lmerTest)
        cond <- bg[i, ]; alpha <- 0.05
        set.seed(SEED + 300000L + cond$condition_id)
        out <- vector("list", N_REP)
        for (r in seq_len(N_REP)) {
          dat <- make_data(cond$J, cond$n, cond$icc, cond$beta1, cond$balance)
          fit <- tryCatch(lmerTest::lmer(Y~X+(1|cluster), data=dat, REML=TRUE),
                          error=function(e) NULL)
          if (is.null(fit)) { # hard failure
            out[[r]] <- data.frame(method=c("KR","Satterthwaite","REML"),
              rep_id=r, condition_id=cond$condition_id, J=cond$J, n_target=cond$n,
              icc=cond$icc, balance=cond$balance, beta1=cond$beta1,
              converged=0L, singular=NA_integer_, boundary=NA_integer_,
              pval=NA_real_, rejected=NA_integer_)
            next
          }
          # yakinsama / singular / boundary tanilari
          conv <- as.integer(is.null(fit@optinfo$conv$lme4$messages))
          sing <- as.integer(lme4::isSingular(fit, tol=1e-4))
          vc   <- as.data.frame(lme4::VarCorr(fit))
          s2u_hat <- vc$vcov[vc$grp=="cluster"][1]
          bound <- as.integer(is.finite(s2u_hat) && s2u_hat < 1e-6)

          b1 <- tryCatch(unname(lme4::fixef(fit)["X"]), error=function(e) NA_real_)
          se <- tryCatch(sqrt(vcov(fit)["X","X"]),      error=function(e) NA_real_)
          rows <- list()
          # REML z
          if (!is.na(b1) && !is.na(se)) {
            pv <- 2*pnorm(abs(b1/se), lower.tail=FALSE)
            rows$reml <- data.frame(method="REML", pval=pv, rejected=as.integer(pv<alpha))
          }
          cs <- tryCatch(summary(fit, ddf="Satterthwaite")$coefficients, error=function(e) NULL)
          if (!is.null(cs) && "X" %in% rownames(cs))
            rows$satt <- data.frame(method="Satterthwaite", pval=cs["X","Pr(>|t|)"],
                                    rejected=as.integer(cs["X","Pr(>|t|)"]<alpha))
          ck <- tryCatch(summary(fit, ddf="Kenward-Roger")$coefficients, error=function(e) NULL)
          if (!is.null(ck) && "X" %in% rownames(ck))
            rows$kr <- data.frame(method="KR", pval=ck["X","Pr(>|t|)"],
                                  rejected=as.integer(ck["X","Pr(>|t|)"]<alpha))
          rr <- do.call(rbind, rows)
          if (!is.null(rr)) {
            rr$rep_id<-r; rr$condition_id<-cond$condition_id; rr$J<-cond$J; rr$n_target<-cond$n
            rr$icc<-cond$icc; rr$balance<-cond$balance; rr$beta1<-cond$beta1
            rr$converged<-conv; rr$singular<-sing; rr$boundary<-bound
          }
          out[[r]] <- rr
        }
        do.call(rbind, Filter(Negate(is.null), out))
      }, .options=furrr_options(seed=TRUE))
      prev <- if (file.exists(CKPT)) readRDS(CKPT) else NULL
      saveRDS(rbind(prev,res), CKPT); rm(res,prev); gc()
      cat(sprintf("  bitti — gecen %.1f dk\n", round((proc.time()-t0)["elapsed"]/60,1)))
    }
  }
  saveRDS(readRDS(CKPT), OUT)
  cat(sprintf("[CONV] TAMAM — satir: %d\n", nrow(readRDS(OUT))))
}

## ---- OZET: oranlar + sensitivity ----
library(dplyr)
d <- readRDS(file.path(DIR,"sim_conv_results.rds"))

cat("\n=== 1. YAKINSAMA / SINGULAR / BOUNDARY oranlari (J x balance) ===\n")
print(as.data.frame(d %>% filter(method=="KR") %>%   # tanilar fit-duzeyinde, yontemden bagimsiz
  group_by(J, balance) %>%
  summarise(conv_rate=round(mean(converged,na.rm=TRUE),3),
            singular_rate=round(mean(singular,na.rm=TRUE),3),
            boundary_rate=round(mean(boundary,na.rm=TRUE),3),
            n=n(), .groups="drop")))

cat("\n=== 2. SENSITIVITY: Tip I hata (beta1=0), DAHIL vs HARIC ===\n")
print(as.data.frame(d %>% filter(beta1==0) %>%
  group_by(method, J) %>%
  summarise(typeI_dahil = round(mean(rejected, na.rm=TRUE),4),
            typeI_haric = round(mean(rejected[converged==1], na.rm=TRUE),4),
            fark = round(mean(rejected,na.rm=TRUE)-mean(rejected[converged==1],na.rm=TRUE),4),
            .groups="drop")))

cat("\n=== 3. SENSITIVITY: Guc (beta1=0.3), DAHIL vs HARIC ===\n")
print(as.data.frame(d %>% filter(beta1==0.3) %>%
  group_by(method, J) %>%
  summarise(power_dahil = round(mean(rejected, na.rm=TRUE),3),
            power_haric = round(mean(rejected[converged==1], na.rm=TRUE),3),
            .groups="drop")))

saveRDS(d, file.path(DIR,"sim_conv_results.rds"))
cat("\n[CONV-AGG] Bitti. Yukaridaki 3 tabloyu Claude'a yolla.\n")
