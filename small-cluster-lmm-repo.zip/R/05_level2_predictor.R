###############################################################################
# KOVA L2 — Level-2 (kume-duzeyi) yordayici alt-calismasi
# Ridvan Kara — Communications in Statistics (revizyon, hakem: Level-1/Level-2 ayrimi)
#
# AMAC: Hakemin en kritik itirazi. Ana calisma X'i Level-1 (X_ij ~ N(0,1)) uretti;
#   bu durumda sabit-etki cikarimi J'den az etkilenir ve duzeltilmemis Wald bile
#   J=3'te Bradley'i karsilar. Ama LMM teorisinde asil tehlike Level-2 yordayicilardadir:
#   Level-2 etkinin efektif orneklem boyutu J'dir, N degil.
#
# Bu alt-calisma HER KUMEYE SABIT bir Z_j ~ N(0,1) (Level-2) degisken atar ve onun
#   sabit etkisini test eder. Beklenti (ve makaleyi guclendiren sonuc):
#   - Duzeltilmemis Wald: J kuculdukce ASIRI RED (over-reject), J=3'te Bradley'i asar.
#   - KR / Satterthwaite: J=3'te bile kalibre kalir (df-duzeltmelerinin NEDEN gerektigi).
#
# Boylece "df-duzeltmeleri gereksiz mi?" sorusuna net cevap: Level-2'de KRITIK.
###############################################################################

.libPaths(c("C:/R_Cloud_Fix", "C:/Program Files/R/R-4.5.2/library"))
cat("\n>>> KOVA L2 — Level-2 yordayici alt-calismasi <<<\n\n")

DIR     <- "C:/simulation_lmm"
SEED    <- 2025
WORKERS <- 3
N_REP   <- 1000

# Ana tasarimla ayni cekirdek faktorler (df-yontemleri, tam degil ama temsili)
L2J    <- c(3, 5, 7, 10, 15)
L2N    <- c(20, 50)
L2ICC  <- c(0.05, 0.30)
L2BAL  <- c("balanced", "unbalanced")
L2GAMMA<- c(0, 0.3, 0.5)      # Level-2 sabit etki: 0 = Tip I ; >0 = guc

dir.create(DIR, showWarnings = FALSE, recursive = TRUE)
.need <- c("lme4","lmerTest","furrr","future","dplyr")
.miss <- .need[!vapply(.need, requireNamespace, logical(1), quietly=TRUE)]
if (length(.miss)) stop("Eksik paket: ", paste(.miss, collapse=", "))

## DGP: Y_ij = beta0 + gamma * Z_j + u_j + e_ij ;  Z_j KUME-DUZEYI (Level-2) ----
## Onemli: Z_j her kume icin TEK deger (kume icinde sabit). Efektif N(Z) = J.
make_data_L2 <- function(J, n_target, icc, gamma, balance) {
  s2u <- icc; s2e <- 1 - icc
  if (identical(balance,"unbalanced")) nj <- pmax(5L, as.integer(round(runif(J, 0.5*n_target, 1.5*n_target))))
  else nj <- rep(as.integer(n_target), J)
  N   <- sum(nj)
  cid <- rep(seq_len(J), times = nj)
  Zj  <- rnorm(J)                       # LEVEL-2 yordayici (kume basina tek)
  uj  <- rnorm(J, 0, sqrt(s2u))
  e   <- rnorm(N) * sqrt(s2e)
  Z_long <- Zj[cid]                     # bireye genisletilmis (kume icinde sabit)
  Y   <- gamma * Z_long + uj[cid] + e
  data.frame(Y = Y, Z = Z_long, cluster = factor(cid))
}

library(furrr); library(future); library(dplyr)
plan(multisession, workers = WORKERS)
CKPT <- file.path(DIR,"sim_level2_checkpoint.rds")
OUT  <- file.path(DIR,"sim_level2_results.rds")

grid <- expand.grid(J=L2J, n=L2N, icc=L2ICC, balance=L2BAL, gamma=L2GAMMA,
                    stringsAsFactors=FALSE)
grid$condition_id <- seq_len(nrow(grid))
done <- if (file.exists(CKPT)) unique(readRDS(CKPT)$condition_id) else integer(0)
todo <- grid[!grid$condition_id %in% done, ]
cat(sprintf("[L2] toplam %d kosul | tamamlanan %d | kalan %d\n", nrow(grid), length(done), nrow(todo)))

if (nrow(todo) > 0) {
  batches <- split(seq_len(nrow(todo)), ceiling(seq_len(nrow(todo))/WORKERS))
  t0 <- proc.time()
  for (b in seq_along(batches)) {
    bg <- todo[batches[[b]], , drop=FALSE]
    cat(sprintf("[%s] L2 batch %d/%d\n", format(Sys.time(),"%H:%M"), b, length(batches)))
    res <- future_map_dfr(seq_len(nrow(bg)), function(i){
      .libPaths(c("C:/R_Cloud_Fix","C:/Program Files/R/R-4.5.2/library"))
      library(lme4); library(lmerTest)
      cond <- bg[i, ]; alpha <- 0.05
      set.seed(SEED + 500000L + cond$condition_id)
      out <- vector("list", N_REP)
      for (r in seq_len(N_REP)) {
        dat <- make_data_L2(cond$J, cond$n, cond$icc, cond$gamma, cond$balance)
        fit <- tryCatch(lmerTest::lmer(Y ~ Z + (1|cluster), data=dat, REML=TRUE),
                        error=function(e) NULL)
        if (is.null(fit)) next
        conv <- as.integer(is.null(fit@optinfo$conv$lme4$messages))
        b1 <- tryCatch(unname(lme4::fixef(fit)["Z"]), error=function(e) NA_real_)
        se <- tryCatch(sqrt(vcov(fit)["Z","Z"]),       error=function(e) NA_real_)
        rows <- list()
        # 1) Uncorrected asymptotic Wald (z)
        if (!is.na(b1) && !is.na(se)) {
          pv <- 2*pnorm(abs(b1/se), lower.tail=FALSE)
          rows$wald <- data.frame(method="Wald", pval=pv, rejected=as.integer(pv<alpha))
        }
        # 2) Satterthwaite
        cs <- tryCatch(summary(fit, ddf="Satterthwaite")$coefficients, error=function(e) NULL)
        if (!is.null(cs) && "Z" %in% rownames(cs))
          rows$satt <- data.frame(method="Satterthwaite", pval=cs["Z","Pr(>|t|)"],
                                  rejected=as.integer(cs["Z","Pr(>|t|)"]<alpha))
        # 3) Kenward-Roger
        ck <- tryCatch(summary(fit, ddf="Kenward-Roger")$coefficients, error=function(e) NULL)
        if (!is.null(ck) && "Z" %in% rownames(ck))
          rows$kr <- data.frame(method="KR", pval=ck["Z","Pr(>|t|)"],
                                rejected=as.integer(ck["Z","Pr(>|t|)"]<alpha))
        rr <- do.call(rbind, rows)
        if (!is.null(rr)) {
          rr$rep_id<-r; rr$condition_id<-cond$condition_id; rr$J<-cond$J; rr$n_target<-cond$n
          rr$icc<-cond$icc; rr$balance<-cond$balance; rr$gamma<-cond$gamma; rr$converged<-conv
        }
        out[[r]] <- rr
      }
      do.call(rbind, Filter(Negate(is.null), out))
    }, .options=furrr_options(seed=TRUE))
    prev <- if (file.exists(CKPT)) readRDS(CKPT) else NULL
    saveRDS(rbind(prev,res), CKPT); rm(res,prev); gc()
    cat(sprintf("  bitti — gecen %.1f dk\n", round((proc.time()-t0)["elapsed"]/60,1)))
  }
}
saveRDS(readRDS(CKPT), OUT)
d <- readRDS(OUT)

## ---- OZET ----
mcse <- function(p,n) round(sqrt(p*(1-p)/n),4)
cat("\n=== L2 TIP I HATA (gamma=0), yontem x J  [Level-2 yordayici] ===\n")
t1 <- d %>% filter(gamma==0) %>% group_by(method,J,condition_id) %>%
  summarise(rate=mean(rejected,na.rm=TRUE), .groups="drop") %>%
  group_by(method,J) %>%
  summarise(typeI=round(mean(rate),4), min=round(min(rate),4), max=round(max(rate),4),
            n_cond=n(), .groups="drop")
print(as.data.frame(t1))

cat("\n=== L2 Bradley uyumu (0.025-0.075) — yontem bazinda ihlal sayisi ===\n")
t2 <- d %>% filter(gamma==0) %>% group_by(method,condition_id) %>%
  summarise(rate=mean(rejected,na.rm=TRUE), .groups="drop") %>%
  group_by(method) %>%
  summarise(n_cond=n(),
            ihlal=sum(rate<0.025 | rate>0.075),
            max_rate=round(max(rate),4),
            .groups="drop")
print(as.data.frame(t2))

cat("\n=== L2 GUC (gamma=0.3 ve 0.5), yontem x J ===\n")
t3 <- d %>% filter(gamma>0) %>% group_by(method,gamma,J,condition_id) %>%
  summarise(rate=mean(rejected,na.rm=TRUE), .groups="drop") %>%
  group_by(method,gamma,J) %>% summarise(power=round(mean(rate),3), .groups="drop")
print(as.data.frame(t3))

cat("\n[L2] Bitti. Yukaridaki 3 tabloyu Claude'a yolla.\n")
cat("BEKLENTI: Wald J=3-5'te Bradley'i ASAR (over-reject); KR/Satterthwaite kalibre kalir.\n")
