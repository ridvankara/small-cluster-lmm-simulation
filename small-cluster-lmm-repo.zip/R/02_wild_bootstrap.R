###############################################################################
# FAZ 1 — Wild Bootstrap for Multilevel Models (yenilik modulu)
# Ridvan Kara — Communications in Statistics - Simulation and Computation
#
# Cok-duzeyli wild bootstrap (Modugno & Giannerini 2015, Comm. Stat. - Theory &
# Methods 44(22):4812-4825), lmeresampler paketi (Loy & Korobova, R Journal 2023)
# uzerinden. KR / Satterthwaite / parametrik bootstrap ile ayni gridde, ayni
# metriklerle KAFA KAFAYA kiyaslanir.
#
# Yenilik cercevesi (dürüst): yontem icat edilmiyor; MEVCUT ama az-degerlendirilmis
# cok-duzeyli wild bootstrap, tam onemli oldugu asiri az-kume rejiminde (J=3-15)
# ilk kez sistematik kiyaslaniyor + ekonometrinin az-kume literaturu ile kopruleniyor.
#
# ONEMLI: aux.dist = "webb" (Webb 6-noktali) — G<=12 kume icin dogru secim.
#         Rademacher J=3,5'te granuler kalir (2^J cok az vektor). Webb 6^J verir.
###############################################################################

.libPaths(c("C:/R_Cloud_Fix", "C:/Program Files/R/R-4.5.2/library"))
## ############################################################################
## ##  WILD PIPELINE v2  (coef_tbl duzeltmesi + 8GB-safe)                     ##
## ##  Bu dosya calisirsa asagidakileri GORMELISIN:                           ##
## ##    >>> WILD PIPELINE v2 ...                                              ##
## ##    [WILD] toplam 60 ... aux={webb}                                       ##
## ##    WILD batch 1/30 — kosul 1:2                                          ##
## ##  Kosul 1 HATA VERMEMELI (pt$coefficients duzeltmesi yapildi).           ##
## ############################################################################
cat("\n>>> WILD PIPELINE v2 yuklendi | WORKERS=2, B_WILD=499, rep=250, aux=webb, coef_tbl-fix <<<\n\n")

## ======================================================= AYARLAR
DIR       <- "C:/simulation_lmm"
SEED      <- 2025
WORKERS   <- 2

RUN_WILD  <- TRUE     # wild bootstrap simulasyonu
RUN_MERGE <- TRUE     # freq + boot + wild birlestir + tam analiz

B_WILD      <- 499                  # wild bootstrap ic ornek (8GB RAM: 499, bootstrap ile tutarli)
N_REP_WILD  <- 250                  # replikasyon / kosul (MCSE ~0.014; bootstrap ile tutarli)
HCCME       <- "hc2"                # marjinal artiklar icin HC kestirici
WILD_AUX    <- c("webb")            # ILK PASS: sadece Webb. Sonra c("webb","rademacher").
WILD_J      <- c(3, 5, 7, 10, 15)   # tum J (parametrik bootstrap ile ayni)
WILD_N      <- c(20, 50)            # kucuk-n rejimi
WILD_ICC    <- c(0.05, 0.30)        # ICC uclari
WILD_BETA   <- c(0, 0.3, 0.5)       # 0 = Tip I ; 0.3/0.5 = guc
# Varsayilan: 5*2*2*3 = 60 kosul x 1 aux = 60. Maliyet ~ parametrik bootstrap ile ayni.
# Yavassa: N_REP_WILD=300 veya WILD_N=c(20). Rademacher karsilastirmasi icin WILD_AUX'e ekle.

dir.create(DIR, showWarnings = FALSE, recursive = TRUE)

## ======================================================= PAKET KONTROLU
.need <- c("lme4","lmerTest","lmeresampler","furrr","future","dplyr")
.miss <- .need[!vapply(.need, requireNamespace, logical(1), quietly = TRUE)]
if (length(.miss)) {
  stop("Eksik paket(ler): ", paste(.miss, collapse=", "),
       "\n  Kurulum: install.packages(c(", paste(sprintf('\"%s\"',.miss),collapse=","), "))")
}
cat("lmeresampler surumu:", as.character(packageVersion("lmeresampler")), "\n")
# aux.dist='webb' destegi eski surumlerde olmayabilir — kontrol:
.wild_args <- names(formals(lmeresampler:::wild_bootstrap.lmerMod))
cat("wild_bootstrap argumanlari:", paste(.wild_args, collapse=", "), "\n")

## ======================================================= ORTAK DGP (ana pipeline ile AYNI)
make_data <- function(J, n_target, icc, beta1, balance) {
  sigma2_u <- icc; sigma2_e <- 1 - icc
  if (identical(balance, "unbalanced")) {
    nj <- pmax(5L, as.integer(round(runif(J, 0.5 * n_target, 1.5 * n_target))))
  } else {
    nj <- rep(as.integer(n_target), J)
  }
  N   <- sum(nj); cid <- rep(seq_len(J), times = nj)
  uj  <- rnorm(J, 0, sqrt(sigma2_u))
  e   <- rnorm(N) * sqrt(sigma2_e)
  X   <- rnorm(N)
  data.frame(Y = beta1 * X + uj[cid] + e, X = X, cluster = factor(cid))
}

## ======================================================= PART D: WILD BOOTSTRAP
if (RUN_WILD) {
  library(furrr); library(future); library(dplyr)
  plan(multisession, workers = WORKERS)

  CKPT <- file.path(DIR, "sim_wild_checkpoint_v2.rds")
  OUT  <- file.path(DIR, "sim_wild_results_v2.rds")

  gridW <- expand.grid(
    J = WILD_J, n = WILD_N, icc = WILD_ICC,
    balance = "balanced", beta1 = WILD_BETA, aux = WILD_AUX,
    stringsAsFactors = FALSE)
  gridW$condition_id <- seq_len(nrow(gridW))

  done <- if (file.exists(CKPT)) unique(readRDS(CKPT)$condition_id) else integer(0)
  todo <- gridW[!gridW$condition_id %in% done, ]
  cat(sprintf("\n[WILD] toplam %d | tamamlanan %d | kalan %d | B=%d rep=%d aux={%s}\n",
              nrow(gridW), length(done), nrow(todo), B_WILD, N_REP_WILD,
              paste(WILD_AUX, collapse=",")))

  if (nrow(todo) > 0) {
    batches <- split(seq_len(nrow(todo)), ceiling(seq_len(nrow(todo))/WORKERS))  # PARALEL: her batch checkpoint
    t0 <- proc.time()

    for (b in seq_along(batches)) {
      bg <- todo[batches[[b]], , drop = FALSE]
      cat(sprintf("[%s] WILD batch %d/%d — kosul %d:%d\n",
          format(Sys.time(),"%H:%M"), b, length(batches),
          bg$condition_id[1], bg$condition_id[nrow(bg)]))

      res <- future_map_dfr(seq_len(nrow(bg)), function(i) {
        .libPaths(c("C:/R_Cloud_Fix","C:/Program Files/R/R-4.5.2/library"))
        library(lme4); library(lmeresampler)
        cond  <- bg[i, ]; alpha <- 0.05
        set.seed(SEED + 200000L + cond$condition_id)   # wild icin ayri tohum uzayi
        out <- vector("list", N_REP_WILD)

        for (r in seq_len(N_REP_WILD)) {
          dat <- make_data(cond$J, cond$n, cond$icc, cond$beta1, cond$balance)
          fit <- tryCatch(lme4::lmer(Y ~ X + (1|cluster), data = dat, REML = TRUE),
                          error = function(e) NULL)
          if (is.null(fit)) next

          pt <- tryCatch(suppressWarnings(
                  lmeresampler::bootstrap_pvals(fit, type = "wild", B = B_WILD,
                                                hccme = HCCME, aux.dist = cond$aux)),
                 error = function(e) NULL)
          if (is.null(pt)) next
          # bootstrap_pvals -> 'coef_tbl' listesi; p-degeri tablosu pt$coefficients icinde
          ptab <- pt$coefficients
          if (is.null(ptab) || !"term" %in% names(ptab)) next
          rowX <- ptab[ptab$term == "X", , drop = FALSE]
          if (nrow(rowX) != 1) next
          pv  <- suppressWarnings(as.numeric(rowX$p.value))
          b1e <- suppressWarnings(as.numeric(rowX$Estimate))
          if (is.na(pv)) next

          out[[r]] <- data.frame(
            method = paste0("Wild-", cond$aux),
            estimate = b1e, se = NA_real_, df = NA_real_,
            pval = pv, ci_lo = NA_real_, ci_hi = NA_real_,
            rejected = as.integer(pv < alpha), covered = NA_integer_,
            rep_id = r, condition_id = cond$condition_id,
            J = cond$J, n_target = cond$n, N_total = nrow(dat), icc = cond$icc,
            balance = cond$balance, beta1 = cond$beta1, aux = cond$aux)
        }
        do.call(rbind, Filter(Negate(is.null), out))
      }, .options = furrr_options(seed = TRUE))

      prev <- if (file.exists(CKPT)) readRDS(CKPT) else NULL
      saveRDS(rbind(prev, res), CKPT); rm(res, prev); gc()
      el <- round((proc.time()-t0)["elapsed"]/60,1)
      cat(sprintf("  bitti — gecen %.1f dk | tahmini kalan %.1f dk\n",
                  el, round(el/b*(length(batches)-b),1)))
    }
  }
  saveRDS(readRDS(CKPT), OUT)
  cat(sprintf("[WILD] TAMAM — satir: %d\n", nrow(readRDS(OUT))))
}

## ======================================================= PART E: BIRLESIK ANALIZ
if (RUN_MERGE) {
  library(dplyr)
  rd <- function(f) if (file.exists(file.path(DIR,f))) readRDS(file.path(DIR,f)) else NULL
  freq <- rd("sim_freq_results_v2.rds")
  boot <- rd("sim_boot_results_v2.rds")
  wild <- rd("sim_wild_results_v2.rds")
  # aux sutunu sadece wild'da var; bind_rows NA ile doldurur
  sim_all <- bind_rows(freq, boot, wild)
  if (nrow(sim_all) == 0) stop("Hic sonuc dosyasi yok.")
  cat("\nYontemler:", paste(sort(unique(sim_all$method)), collapse=", "), "\n")

  cell <- sim_all %>%
    group_by(method, J, n_target, icc, balance, beta1) %>%
    summarise(
      R           = dplyr::n(),
      reject      = mean(rejected, na.rm=TRUE),
      reject_mcse = sqrt(reject*(1-reject)/R),
      n_cov       = sum(!is.na(covered)),
      coverage    = ifelse(n_cov>0, mean(covered, na.rm=TRUE), NA_real_),
      cover_mcse  = ifelse(n_cov>0, sqrt(coverage*(1-coverage)/n_cov), NA_real_),
      .groups="drop")

  typeI <- cell %>% filter(beta1==0) %>%
    transmute(method,J,n_target,icc,balance,typeI=reject,typeI_mcse=reject_mcse,coverage,R)

  # --- size-adjusted power (madde 6), TUM yontemler dahil ---
  sap <- sim_all %>%
    group_by(method,J,n_target,icc,balance) %>%
    group_modify(function(df, key){
      nullp <- df$pval[df$beta1==0]; nullp <- nullp[is.finite(nullp)]
      empty <- data.frame(beta1=numeric(0), p_crit=numeric(0),
                          nominal_power=numeric(0), sizeadj_power=numeric(0), R=integer(0))
      if (length(nullp) < 30) return(empty)
      pcrit <- as.numeric(quantile(nullp, 0.05, type=1, na.rm=TRUE))
      df %>% filter(beta1>0, is.finite(pval)) %>%
        group_by(beta1) %>%
        summarise(p_crit=pcrit,
                  nominal_power=mean(pval<0.05),
                  sizeadj_power=mean(pval<pcrit),
                  R=dplyr::n(), .groups="drop")
    }) %>% ungroup()

  saveRDS(list(cell=cell, typeI=typeI, sizeadj=sap),
          file.path(DIR,"summary_tables_final_v2.rds"))

  cat("\n=============== BIRLESIK OZET ===============\n")
  cat("\n--- TIP I HATA (yontem ortalamasi) ---\n")
  print(as.data.frame(typeI %>% group_by(method) %>%
    summarise(mean_typeI=round(mean(typeI,na.rm=TRUE),4),
              max_typeI=round(max(typeI,na.rm=TRUE),4),
              bradley_ok=round(mean(typeI>=0.025 & typeI<=0.075,na.rm=TRUE),3),
              .groups="drop")))

  cat("\n--- MADDE 6: eslesen hucrelerde yontem karsilastirmasi (nominal vs size-adj guc) ---\n")
  # wild ve bootstrap'in ortak hucrelerinde KR ile kiyasla
  focus_cells <- sap %>% filter(method %in% c("Bootstrap") | grepl("^Wild", method)) %>%
    distinct(J,n_target,icc,balance,beta1)
  m6 <- sap %>%
    semi_join(focus_cells, by=c("J","n_target","icc","balance","beta1")) %>%
    filter(method %in% c("KR","Satterthwaite","Bootstrap") | grepl("^Wild", method)) %>%
    group_by(method,beta1) %>%
    summarise(nominal=round(mean(nominal_power,na.rm=TRUE),3),
              sizeadj=round(mean(sizeadj_power,na.rm=TRUE),3), .groups="drop")
  print(as.data.frame(m6))

  cat("\n--- WILD: J'ye gore Tip I hata (kucuk-kume davranisi) ---\n")
  print(as.data.frame(typeI %>% filter(grepl("^Wild", method)) %>%
    group_by(method,J) %>%
    summarise(mean_typeI=round(mean(typeI,na.rm=TRUE),4),
              max_typeI=round(max(typeI,na.rm=TRUE),4), .groups="drop")))

  cat("\n[MERGE] Kaydedildi: summary_tables_final_v2.rds\n")
}
