###############################################################################
# FIGURLER — Revizyon (yeni verilerden)
# Ridvan Kara — Communications in Statistics - Simulation and Computation
#
# Okur: sim_freq_results_v2, sim_boot_results_v2, sim_wild_results_v2,
#       sim_phase2_results. Yazar: C:/simulation_lmm/figures/*.png (300 dpi)
#
# Fig 1: Tip I hata — yontem x J (ana karsilastirma, Bradley bandi)
# Fig 2: Wild bootstrap — Tip I + guc x J (yenilik: J=3 cokus, J>=5 toparlanma)
# Fig 3: Guc — yontem x J (d=0.30)
# Fig 4: Faz 2 — Tip I hata senaryo x yontem (kovaryat/eksik dayaniklilik)
# Fig 5: Yakinsama orani x J (az-kume kirilganligi)
###############################################################################

.libPaths(c("C:/R_Cloud_Fix", "C:/Program Files/R/R-4.5.2/library"))
for (p in c("ggplot2","dplyr")) if (!requireNamespace(p, quietly=TRUE))
  stop("Eksik paket: ", p, " — install.packages('", p, "')")
library(ggplot2); library(dplyr)

DIR    <- "C:/simulation_lmm"
FIGDIR <- file.path(DIR, "figures")
dir.create(FIGDIR, showWarnings = FALSE, recursive = TRUE)

## --- Veri ---
freq <- readRDS(file.path(DIR,"sim_freq_results_v2.rds"))
boot <- readRDS(file.path(DIR,"sim_boot_results_v2.rds"))
wild <- readRDS(file.path(DIR,"sim_wild_results_v2.rds"))
all  <- bind_rows(freq, boot, wild)

# Ortak hucreler (adil kiyas): dengeli, n=20/50, icc=0.05/0.30, tum J
common <- all %>% filter(balance=="balanced",
                         n_target %in% c(20,50),
                         icc %in% c(0.05,0.30),
                         J %in% c(3,5,7,10,15))

meth_levels <- c("REML","Satterthwaite","KR","Bootstrap","Wild-webb")
meth_cols   <- c(REML="#777777", Satterthwaite="#0072B2", KR="#009E73",
                 Bootstrap="#E69F00", `Wild-webb`="#CC79A7")

base_theme <- theme_bw(base_size = 12) +
  theme(panel.grid.minor = element_blank(),
        legend.position = "bottom",
        strip.background = element_rect(fill="grey92"))

## ======================= FIG 1: Tip I hata — yontem x J ======================
f1 <- common %>% filter(beta1==0) %>%
  group_by(method, J) %>%
  summarise(typeI=mean(rejected), R=dplyr::n(),
            mcse=sqrt(typeI*(1-typeI)/R), .groups="drop") %>%
  mutate(method=factor(method, levels=meth_levels))

p1 <- ggplot(f1, aes(J, typeI, color=method, group=method)) +
  annotate("rect", xmin=-Inf, xmax=Inf, ymin=0.025, ymax=0.075,
           fill="grey85", alpha=0.5) +
  geom_hline(yintercept=0.05, linetype="dotted", color="grey40") +
  geom_line(linewidth=0.7) +
  geom_point(size=2.2) +
  geom_errorbar(aes(ymin=typeI-mcse, ymax=typeI+mcse), width=0.4, linewidth=0.5) +
  scale_color_manual(values=meth_cols, name=NULL) +
  scale_x_continuous(breaks=c(3,5,7,10,15)) +
  labs(x="Number of clusters (J)", y="Type I error rate",
       caption="Shaded band: Bradley (1978) liberal criterion [0.025, 0.075]. Dotted line: nominal 0.05. Bars: \u00b11 MCSE.") +
  base_theme
ggsave(file.path(FIGDIR,"fig1_typeI_by_method_J.png"), p1, width=7, height=5, dpi=300)

## ======================= FIG 2: Wild — Tip I + guc x J ========================
w_typeI <- wild %>% filter(beta1==0) %>% group_by(J) %>%
  summarise(value=mean(rejected), R=dplyr::n(),
            mcse=sqrt(value*(1-value)/R), .groups="drop") %>%
  mutate(panel="(a) Type I error (\u03b2\u2081 = 0)")
w_pow <- wild %>% filter(beta1==0.3) %>% group_by(J) %>%
  summarise(value=mean(rejected), R=dplyr::n(),
            mcse=sqrt(value*(1-value)/R), .groups="drop") %>%
  mutate(panel="(b) Power (d = 0.30)")
f2 <- bind_rows(w_typeI, w_pow)

p2 <- ggplot(f2, aes(J, value)) +
  geom_line(linewidth=0.7, color="#CC79A7") +
  geom_point(size=2.4, color="#CC79A7") +
  geom_errorbar(aes(ymin=value-mcse, ymax=value+mcse), width=0.4,
                linewidth=0.5, color="#CC79A7") +
  geom_vline(xintercept=5, linetype="dashed", color="grey50") +
  facet_wrap(~panel, scales="free_y") +
  scale_x_continuous(breaks=c(3,5,7,10,15)) +
  labs(x="Number of clusters (J)", y="Rejection rate",
       caption="Wild bootstrap (Webb weights). Dashed line at J=5: validity threshold. Left: collapses at J=3 (0.001).") +
  base_theme
ggsave(file.path(FIGDIR,"fig2_wild_typeI_power.png"), p2, width=8, height=4.2, dpi=300)

## ======================= FIG 3: Guc — yontem x J (d=0.30) =====================
f3 <- common %>% filter(beta1==0.3) %>%
  group_by(method, J) %>%
  summarise(power=mean(rejected), R=dplyr::n(),
            mcse=sqrt(power*(1-power)/R), .groups="drop") %>%
  mutate(method=factor(method, levels=meth_levels))

p3 <- ggplot(f3, aes(J, power, color=method, group=method)) +
  geom_line(linewidth=0.7) + geom_point(size=2.2) +
  geom_errorbar(aes(ymin=power-mcse, ymax=power+mcse), width=0.4, linewidth=0.5) +
  scale_color_manual(values=meth_cols, name=NULL) +
  scale_x_continuous(breaks=c(3,5,7,10,15)) +
  labs(x="Number of clusters (J)", y="Power (d = 0.30)",
       caption="Bars: \u00b11 MCSE. Wild bootstrap has ~zero power at J=3 (invalid), competitive from J\u22655.") +
  base_theme
ggsave(file.path(FIGDIR,"fig3_power_by_method_J.png"), p3, width=7, height=5, dpi=300)

## ======================= FIG 4: Faz 2 — Tip I senaryo x yontem ===============
p2dat <- readRDS(file.path(DIR,"sim_phase2_results.rds"))
p2dat$scenario <- ifelse(is.na(p2dat$mechanism), "Covariates (3)",
                    ifelse(p2dat$mechanism=="MCAR","Missing MCAR","Missing MAR"))
# Baseline: ana calisma, ayni gride (dengeli, n 20/50, icc 0.05/0.30, J 3/5/10/15)
base <- freq %>% filter(balance=="balanced", n_target %in% c(20,50),
                        icc %in% c(0.05,0.30), J %in% c(3,5,10,15)) %>%
  mutate(scenario="Baseline")

f4 <- bind_rows(
  base %>% transmute(scenario, method, J, beta1, rejected),
  p2dat %>% transmute(scenario, method, J, beta1, rejected)
) %>% filter(beta1==0) %>%
  group_by(scenario, method) %>%
  summarise(typeI=mean(rejected), R=dplyr::n(),
            mcse=sqrt(typeI*(1-typeI)/R), .groups="drop") %>%
  mutate(method=factor(method, levels=c("REML","Satterthwaite","KR")),
         scenario=factor(scenario, levels=c("Baseline","Covariates (3)",
                                            "Missing MCAR","Missing MAR")))

p4 <- ggplot(f4, aes(scenario, typeI, fill=method)) +
  annotate("rect", xmin=-Inf, xmax=Inf, ymin=0.025, ymax=0.075,
           fill="grey85", alpha=0.5) +
  geom_hline(yintercept=0.05, linetype="dotted", color="grey40") +
  geom_col(position=position_dodge(0.7), width=0.65) +
  geom_errorbar(aes(ymin=typeI-mcse, ymax=typeI+mcse),
                position=position_dodge(0.7), width=0.25, linewidth=0.4) +
  scale_fill_manual(values=meth_cols[c("REML","Satterthwaite","KR")], name=NULL) +
  coord_cartesian(ylim=c(0,0.09)) +
  labs(x=NULL, y="Type I error rate",
       caption="Band: Bradley [0.025,0.075]. df-corrections remain valid under covariates and 20% missingness.") +
  base_theme + theme(axis.text.x=element_text(angle=15, hjust=1))
ggsave(file.path(FIGDIR,"fig4_phase2_typeI.png"), p4, width=7.5, height=5, dpi=300)

## ======================= FIG 5: Yakinsama orani x J ==========================
f5 <- p2dat %>% group_by(scenario, J) %>%
  summarise(conv=mean(converged, na.rm=TRUE), .groups="drop") %>%
  mutate(scenario=factor(scenario, levels=c("Covariates (3)","Missing MCAR","Missing MAR")))

p5 <- ggplot(f5, aes(J, conv, color=scenario, group=scenario)) +
  geom_line(linewidth=0.7) + geom_point(size=2.2) +
  scale_color_brewer(palette="Dark2", name=NULL) +
  scale_x_continuous(breaks=c(3,5,10,15)) +
  scale_y_continuous(labels=scales::percent_format(accuracy=1)) +
  labs(x="Number of clusters (J)", y="Convergence rate",
       caption="Model convergence falls to ~78% at J=3 \u2014 evidence of small-cluster fragility.") +
  base_theme
ggsave(file.path(FIGDIR,"fig5_convergence_by_J.png"), p5, width=7, height=5, dpi=300)

cat("\n5 figur kaydedildi:", FIGDIR, "\n")
cat(list.files(FIGDIR, pattern="\\.png$"), sep="\n")
