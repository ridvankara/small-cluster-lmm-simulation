###############################################################################
# Small-Cluster LMM Inference — Birlesik Simulasyon Pipeline (revizyon surumu)
# Ridvan Kara — Communications in Statistics - Simulation and Computation
#
# Bu TEK dosya, ustteki anahtarlarla acilip kapanan uc bolumden olusur:
#   PART A  Frequentist simulasyon (REML, Satterthwaite, KR) — tam 360 kosul
#   PART B  Parametrik bootstrap — nsim=999, TUM J duzeyleri (3,5,7,10,15)
#   PART C  Toplulastirma + MCSE + size-adjusted power (analiz; saniyeler surer)
#
# HAKEM DUZELTMELERI (kodda nerede):
#   madde 7  : NSIM_BOOT = 999            (eski 99 -> p-degeri cozunurlugu duzeldi)
#   madde 10 : dengesiz kume boyutlari hedef n ETRAFINDA (make_data icinde)
#              -> n artik islevsel; dengesiz n=20 test ediliyor;
#                 toplam N dengeli kosul ile eslesiyor (confound kalkti)
#   madde 2  : bootstrap J = 3,5,7,10,15  (eskiden yalniz 3,5)
#   madde 6  : size-adjusted power        (PART C — esit gercek alfa'da guc)
#   madde 3  : her hucre icin analitik MCSE (PART C)
#
# Uretilebilirlik: her kosul SEED + condition_id ile tohumlanir; tam bir
# bastan-sona kosu tamamen tekrar-uretilebilir. Checkpoint'ler .rds olarak
# C:/simulation_lmm altina yazilir; kod kesilirse kaldigi yerden devam eder.
###############################################################################

.libPaths(c("C:/R_Cloud_Fix", "C:/Program Files/R/R-4.5.2/library"))

## ############################################################################
## ##  SURUM: v5  (WORKERS=2, NSIM_BOOT=499 — 8GB RAM bellek-guvenli)            ##
## ##  Bu dosya calisirsa asagida sunlari GORMELISIN:                          ##
## ##    [BOOT] ... nsim=499 rep=250   (nsim=999 DEGIL)                                  ##
## ##    BOOT batch X/30           (60 kosul / 2 worker = 30 batch)                                 ##
## ##  Bunlari gormuyorsan yanlis dosya calisiyor.                             ##
## ############################################################################
cat("\n>>> SIM PIPELINE v5 yuklendi | WORKERS=2, NSIM_BOOT=499, rep=250 (8GB RAM bellek-guvenli) <<<\n\n")


## ======================================================= AYARLAR (buradan oynanir)
DIR      <- "C:/simulation_lmm"
SEED     <- 2025
WORKERS  <- 2

RUN_FREQ <- TRUE     # PART A  (frequentist tam grid; ~onceki kosuda 34 saat civari)
RUN_BOOT <- TRUE     # PART B  (bootstrap; UZUN — asagidaki notu oku)
RUN_AGG  <- TRUE     # PART C  (analiz; hizli)

N_REP    <- 1000     # frequentist replikasyon / kosul

# --- Bootstrap ayarlari (PAHALI kisim — sureyi buradan kisarsin) ---
NSIM_BOOT   <- 499               # bootstrap ic ornek (madde 7; 8GB RAM: 499, 0.05*500=25 tam)
N_REP_BOOT  <- 250               # bootstrap replikasyon / kosul (MCSE ~0.014)
BOOT_J      <- c(3, 5, 7, 10, 15)   # madde 2: tum J duzeyleri
BOOT_N      <- c(20, 50)          # kucuk-n rejimi (bootstrap'in onemli oldugu yer)
BOOT_ICC    <- c(0.05, 0.30)      # ICC uclari (davranis ICC'de monoton)
BOOT_BETA   <- c(0, 0.3, 0.5)     # 0 = Tip I ; 0.3/0.5 = guc
COMPUTE_BOOT_CI <- FALSE          # TRUE: gercek bootstrap yuzdelik CI (sureyi ~2x'ler)
# Varsayilan bootstrap gridi: 5*2*2*3 = 60 kosul.
# ONERI: once RUN_BOOT=FALSE ile PART A'yi kosup ilk checkpoint'i bana gonder;
#        sonra RUN_FREQ=FALSE / RUN_BOOT=TRUE yapip bootstrap'i ayri kos.
# Cok yavassa: N_REP_BOOT=300 ya da BOOT_N=c(20) ya da NSIM_BOOT=499 yap.

dir.create(DIR, showWarnings = FALSE, recursive = TRUE)

## ======================================================= PAKET KONTROLU (hizli hata)
.need <- c("lme4","lmerTest","pbkrtest","furrr","future","dplyr")
.miss <- .need[!vapply(.need, requireNamespace, logical(1), quietly = TRUE)]
if (length(.miss)) stop("Eksik paket(ler): ", paste(.miss, collapse=", "))
cat("Paket surumleri:\n")
for (p in .need) cat(sprintf("  %-10s %s\n", p, as.character(packageVersion(p))))
writeLines(capture.output(sessionInfo()), file.path(DIR, "sessionInfo.txt"))

## ======================================================= ORTAK DGP FONKSIYONU
# Hem frequentist hem bootstrap AYNI veri uretimini kullanir.
# Cizim sirasi (balanced): rnorm(J)=uj, rnorm(N)=e, rnorm(N)=X  (eski kod ile ayni).
# Dengesiz (madde 10 duzeltmesi): kume boyutlari hedef n ETRAFINDA, ort = n,
# maks/min orani ~3:1 (eski Uniform[50,150]'nin dengesizlik karakterini korur
# ama artik n=20/50/150 gercekten farkli olur; dengesiz n=20 de test edilir).
make_data <- function(J, n_target, icc, beta1, balance) {
  sigma2_u <- icc; sigma2_e <- 1 - icc
  if (identical(balance, "unbalanced")) {
    nj <- pmax(5L, as.integer(round(runif(J, 0.5 * n_target, 1.5 * n_target))))
  } else {
    nj <- rep(as.integer(n_target), J)
  }
  N   <- sum(nj)
  cid <- rep(seq_len(J), times = nj)
  uj  <- rnorm(J, 0, sqrt(sigma2_u))
  e   <- rnorm(N) * sqrt(sigma2_e)
  X   <- rnorm(N)
  data.frame(Y = beta1 * X + uj[cid] + e, X = X, cluster = factor(cid))
}

## ======================================================= PART A: FREQUENTIST
if (RUN_FREQ) {
  library(furrr); library(future); library(dplyr)
  plan(multisession, workers = WORKERS)

  CKPT <- file.path(DIR, "sim_freq_checkpoint_v2.rds")
  OUT  <- file.path(DIR, "sim_freq_results_v2.rds")

  grid <- expand.grid(
    J = c(3,5,7,10,15), n = c(20,50,150),
    icc = c(0.05,0.15,0.30,0.50),
    balance = c("balanced","unbalanced"),
    beta1 = c(0,0.3,0.5),
    stringsAsFactors = FALSE)
  grid$condition_id <- seq_len(nrow(grid))   # 5*3*4*2*3 = 360

  done <- if (file.exists(CKPT)) unique(readRDS(CKPT)$condition_id) else integer(0)
  todo <- grid[!grid$condition_id %in% done, ]
  cat(sprintf("\n[FREQ] toplam %d | tamamlanan %d | kalan %d\n",
              nrow(grid), length(done), nrow(todo)))

  if (nrow(todo) > 0) {
    batches <- split(seq_len(nrow(todo)), ceiling(seq_len(nrow(todo))/10))
    t0 <- proc.time()

    for (b in seq_along(batches)) {
      bg <- todo[batches[[b]], , drop = FALSE]
      cat(sprintf("[%s] FREQ batch %d/%d — kosul %d:%d\n",
          format(Sys.time(),"%H:%M"), b, length(batches),
          bg$condition_id[1], bg$condition_id[nrow(bg)]))

      res <- future_map_dfr(seq_len(nrow(bg)), function(i) {
        .libPaths(c("C:/R_Cloud_Fix","C:/Program Files/R/R-4.5.2/library"))
        library(lme4); library(lmerTest); library(pbkrtest)
        cond  <- bg[i, ]; alpha <- 0.05
        set.seed(SEED + cond$condition_id)          # kosula ozgu tohum
        out <- vector("list", N_REP)

        for (r in seq_len(N_REP)) {
          dat <- make_data(cond$J, cond$n, cond$icc, cond$beta1, cond$balance)
          fit <- tryCatch(lmerTest::lmer(Y ~ X + (1|cluster), data = dat, REML = TRUE),
                          error = function(e) NULL)
          if (is.null(fit)) next
          b1e    <- tryCatch(unname(lme4::fixef(fit)["X"]), error=function(e) NA_real_)
          se_raw <- tryCatch(sqrt(vcov(fit)["X","X"]),      error=function(e) NA_real_)
          if (is.na(b1e) || is.na(se_raw)) next
          Ntot <- nrow(dat); truth <- cond$beta1
          rows <- list()

          # REML (duzeltilmemis; asimptotik z-testi)
          z  <- b1e / se_raw
          pv <- 2 * pnorm(abs(z), lower.tail = FALSE)
          ci <- b1e + c(-1,1) * qnorm(1-alpha/2) * se_raw
          rows$reml <- data.frame(method="REML", estimate=b1e, se=se_raw, df=NA_real_,
            pval=pv, ci_lo=ci[1], ci_hi=ci[2],
            rejected=as.integer(pv<alpha),
            covered=as.integer(ci[1]<=truth & truth<=ci[2]))

          # Satterthwaite (ayni SE, duzeltilmis df, t-testi)
          cs <- tryCatch(summary(fit, ddf="Satterthwaite")$coefficients,
                         error=function(e) NULL)
          if (!is.null(cs) && "X" %in% rownames(cs)) {
            se_s<-cs["X","Std. Error"]; df_s<-cs["X","df"]; pv_s<-cs["X","Pr(>|t|)"]
            ci_s<-b1e + c(-1,1)*qt(1-alpha/2, df_s)*se_s
            rows$satt <- data.frame(method="Satterthwaite", estimate=b1e, se=se_s, df=df_s,
              pval=pv_s, ci_lo=ci_s[1], ci_hi=ci_s[2],
              rejected=as.integer(pv_s<alpha),
              covered=as.integer(ci_s[1]<=truth & truth<=ci_s[2]))
          }

          # Kenward-Roger (duzeltilmis SE + df, t-testi)
          ck <- tryCatch(summary(fit, ddf="Kenward-Roger")$coefficients,
                         error=function(e) NULL)
          if (!is.null(ck) && "X" %in% rownames(ck)) {
            se_k<-ck["X","Std. Error"]; df_k<-ck["X","df"]; pv_k<-ck["X","Pr(>|t|)"]
            ci_k<-b1e + c(-1,1)*qt(1-alpha/2, df_k)*se_k
            rows$kr <- data.frame(method="KR", estimate=b1e, se=se_k, df=df_k,
              pval=pv_k, ci_lo=ci_k[1], ci_hi=ci_k[2],
              rejected=as.integer(pv_k<alpha),
              covered=as.integer(ci_k[1]<=truth & truth<=ci_k[2]))
          }

          rr <- do.call(rbind, rows)
          if (!is.null(rr)) {
            rr$rep_id<-r; rr$condition_id<-cond$condition_id
            rr$J<-cond$J; rr$n_target<-cond$n; rr$N_total<-Ntot; rr$icc<-cond$icc
            rr$balance<-cond$balance; rr$beta1<-cond$beta1
          }
          out[[r]] <- rr
        }
        do.call(rbind, Filter(Negate(is.null), out))
      }, .options = furrr_options(seed = TRUE))

      prev <- if (file.exists(CKPT)) readRDS(CKPT) else NULL
      saveRDS(rbind(prev, res), CKPT); rm(res, prev); gc()
      el <- round((proc.time()-t0)["elapsed"]/60,1)
      cat(sprintf("  bitti — gecen %.1f dk | tahmini kalan %.1f dk\n",
                  el, round(el/b*(length(batches)-b),1)))
    }
  }
  saveRDS(readRDS(CKPT), OUT)
  cat(sprintf("[FREQ] TAMAM — satir: %d\n", nrow(readRDS(OUT))))
}

## ======================================================= PART B: BOOTSTRAP
if (RUN_BOOT) {
  library(furrr); library(future); library(dplyr)
  plan(multisession, workers = WORKERS)

  CKPT <- file.path(DIR, "sim_boot_checkpoint_v2.rds")
  OUT  <- file.path(DIR, "sim_boot_results_v2.rds")

  gridB <- expand.grid(
    J = BOOT_J, n = BOOT_N, icc = BOOT_ICC,
    balance = "balanced", beta1 = BOOT_BETA,
    stringsAsFactors = FALSE)
  gridB$condition_id <- seq_len(nrow(gridB))

  done <- if (file.exists(CKPT)) unique(readRDS(CKPT)$condition_id) else integer(0)
  todo <- gridB[!gridB$condition_id %in% done, ]
  cat(sprintf("\n[BOOT] toplam %d | tamamlanan %d | kalan %d | nsim=%d rep=%d\n",
              nrow(gridB), length(done), nrow(todo), NSIM_BOOT, N_REP_BOOT))

  if (nrow(todo) > 0) {
    batches <- split(seq_len(nrow(todo)), ceiling(seq_len(nrow(todo))/WORKERS))  # PARALEL: worker kadar kosul/batch, her batch checkpoint
    t0 <- proc.time()

    for (b in seq_along(batches)) {
      bg <- todo[batches[[b]], , drop = FALSE]
      cat(sprintf("[%s] BOOT batch %d/%d — kosul %d:%d\n",
          format(Sys.time(),"%H:%M"), b, length(batches),
          bg$condition_id[1], bg$condition_id[nrow(bg)]))

      res <- future_map_dfr(seq_len(nrow(bg)), function(i) {
        .libPaths(c("C:/R_Cloud_Fix","C:/Program Files/R/R-4.5.2/library"))
        library(lme4); library(pbkrtest)
        cond  <- bg[i, ]; alpha <- 0.05
        set.seed(SEED + 100000L + cond$condition_id)   # bootstrap icin ayri tohum uzayi
        out <- vector("list", N_REP_BOOT)

        for (r in seq_len(N_REP_BOOT)) {
          dat <- make_data(cond$J, cond$n, cond$icc, cond$beta1, cond$balance)
          fit_full <- tryCatch(lme4::lmer(Y~X+(1|cluster), data=dat, REML=FALSE),
                               error=function(e) NULL)
          fit_null <- tryCatch(lme4::lmer(Y~1+(1|cluster), data=dat, REML=FALSE),
                               error=function(e) NULL)
          if (is.null(fit_full) || is.null(fit_null)) next

          pb <- tryCatch(suppressWarnings(
                  pbkrtest::PBmodcomp(fit_full, fit_null, nsim=NSIM_BOOT, seed=NULL)),
                 error=function(e) NULL)
          if (is.null(pb)) next
          pv <- tryCatch(pb$test["PBtest","p.value"], error=function(e) NA_real_)
          if (is.na(pv)) next
          b1e <- tryCatch(unname(lme4::fixef(fit_full)["X"]), error=function(e) NA_real_)

          ci_lo<-NA_real_; ci_hi<-NA_real_; covered<-NA_integer_
          if (COMPUTE_BOOT_CI) {
            bb <- tryCatch(suppressWarnings(
                    lme4::bootMer(fit_full, function(m) unname(lme4::fixef(m)["X"]),
                                  nsim=NSIM_BOOT, type="parametric")),
                   error=function(e) NULL)
            if (!is.null(bb)) {
              q <- quantile(bb$t[,1], c(alpha/2, 1-alpha/2), na.rm=TRUE)
              ci_lo<-unname(q[1]); ci_hi<-unname(q[2])
              covered<-as.integer(ci_lo<=cond$beta1 & cond$beta1<=ci_hi)
            }
          }

          out[[r]] <- data.frame(
            method="Bootstrap", estimate=b1e, se=NA_real_, df=NA_real_,
            pval=pv, ci_lo=ci_lo, ci_hi=ci_hi,
            rejected=as.integer(pv<alpha), covered=covered,
            rep_id=r, condition_id=cond$condition_id,
            J=cond$J, n_target=cond$n, N_total=nrow(dat), icc=cond$icc,
            balance=cond$balance, beta1=cond$beta1)
        }
        do.call(rbind, Filter(Negate(is.null), out))
      }, .options = furrr_options(seed = TRUE))

      prev <- if (file.exists(CKPT)) readRDS(CKPT) else NULL
      saveRDS(rbind(prev, res), CKPT); rm(res, prev); gc()
      el <- round((proc.time()-t0)["elapsed"]/60,1)
      cat(sprintf("  bitti — gecen %.1f dk | tahmini kalan %.1f dk\n",
                  el, round(el/b*(length(batches)-b),1)))
    }
  }
  saveRDS(readRDS(CKPT), OUT)
  cat(sprintf("[BOOT] TAMAM — satir: %d\n", nrow(readRDS(OUT))))
}

## ======================================================= PART C: TOPLULASTIRMA + MCSE + SAP
if (RUN_AGG) {
  library(dplyr)
  f_freq <- file.path(DIR,"sim_freq_results_v2.rds")
  f_boot <- file.path(DIR,"sim_boot_results_v2.rds")
  freq <- if (file.exists(f_freq)) readRDS(f_freq) else NULL
  boot <- if (file.exists(f_boot)) readRDS(f_boot) else NULL
  sim_all <- bind_rows(freq, boot)
  if (nrow(sim_all) == 0) stop("Sonuc dosyasi bulunamadi — once PART A/B kosulmali.")

  # --- Hucre bazinda performans + analitik MCSE (madde 3) ---
  cell <- sim_all %>%
    group_by(method, J, n_target, icc, balance, beta1) %>%
    summarise(
      R           = dplyr::n(),
      reject      = mean(rejected, na.rm=TRUE),
      reject_mcse = sqrt(reject*(1-reject)/R),
      n_cov       = sum(!is.na(covered)),
      coverage    = ifelse(n_cov>0, mean(covered, na.rm=TRUE), NA_real_),
      cover_mcse  = ifelse(n_cov>0, sqrt(coverage*(1-coverage)/n_cov), NA_real_),
      se_mean     = mean(se, na.rm=TRUE),
      .groups="drop")

  typeI <- cell %>% filter(beta1==0) %>%
    transmute(method,J,n_target,icc,balance,
              typeI=reject, typeI_mcse=reject_mcse, coverage, cover_mcse, R)
  power <- cell %>% filter(beta1>0) %>%
    transmute(method,J,n_target,icc,balance,beta1,
              power=reject, power_mcse=reject_mcse, R)

  # --- madde 6: size-adjusted power ---
  # Her method x (J,n,icc,balance): null p-degerlerinden gercek 0.05 esigi (pcrit),
  # sonra alt kosullara uygulanir -> esit gercek alfa'da guc.
  sap <- sim_all %>%
    group_by(method,J,n_target,icc,balance) %>%
    group_modify(function(df, key){
      nullp <- df$pval[df$beta1==0]; nullp <- nullp[is.finite(nullp)]
      empty <- data.frame(beta1=numeric(0), p_crit=numeric(0),
                          nominal_power=numeric(0), sizeadj_power=numeric(0),
                          R=integer(0))
      if (length(nullp) < 30) return(empty)
      pcrit <- as.numeric(quantile(nullp, 0.05, type=1, na.rm=TRUE))
      df %>% filter(beta1>0, is.finite(pval)) %>%
        group_by(beta1) %>%
        summarise(p_crit=pcrit,
                  nominal_power = mean(pval < 0.05),
                  sizeadj_power = mean(pval < pcrit),
                  R = dplyr::n(), .groups="drop")
    }) %>% ungroup()

  saveRDS(list(cell=cell, typeI=typeI, power=power, sizeadj=sap),
          file.path(DIR,"summary_tables_v2.rds"))

  cat("\n================= OZET =================\n")
  cat("\n--- TIP I HATA (method ortalamasi) ---\n")
  print(as.data.frame(typeI %>% group_by(method) %>%
        summarise(mean_typeI=round(mean(typeI,na.rm=TRUE),4),
                  min=round(min(typeI,na.rm=TRUE),4),
                  max=round(max(typeI,na.rm=TRUE),4),
                  bradley_ok=round(mean(typeI>=0.025 & typeI<=0.075, na.rm=TRUE),3),
                  .groups="drop")))

  cat("\n--- KAPSAMA (coverage, method ortalamasi) ---\n")
  print(as.data.frame(typeI %>% group_by(method) %>%
        summarise(mean_cov=round(mean(coverage,na.rm=TRUE),4), .groups="drop")))

  cat("\n--- MADDE 6: eslesen hucrelerde Bootstrap vs KR (nominal vs size-adj guc) ---\n")
  boot_cells <- sap %>% filter(method=="Bootstrap") %>%
    distinct(J,n_target,icc,balance,beta1)
  m6 <- sap %>%
    semi_join(boot_cells, by=c("J","n_target","icc","balance","beta1")) %>%
    filter(method %in% c("Bootstrap","KR")) %>%
    group_by(method,beta1) %>%
    summarise(nominal=round(mean(nominal_power,na.rm=TRUE),3),
              sizeadj=round(mean(sizeadj_power,na.rm=TRUE),3), .groups="drop")
  print(as.data.frame(m6))

  cat("\n[AGG] Ozet tablolar kaydedildi: ", file.path(DIR,"summary_tables_v2.rds"), "\n")
}
